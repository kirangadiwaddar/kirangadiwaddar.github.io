// CUSTOM JQUERY CODE 

$(document).ready(function(){

	$('.all').click(function(){
		$('li').show(700);
	});

	$('.Hollywood_class').click(function(){
		$('.bollywood').hide(700);
		$('.hollywood').show(700);
	});

	$('.Bollywood_class').click(function(){
		$('.hollywood').hide(700);
		$('.bollywood').show(700);
	});
});